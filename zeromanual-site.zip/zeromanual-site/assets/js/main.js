(function () {
  const root = document.documentElement;
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------- Language toggle ---------------- */
  const langButtons = document.querySelectorAll('[data-set-lang]');
  const binTimeEl = document.getElementById('bin-time');

  const binTimeText = {
    vi: '6 tệp đã đổi tên trong 0.3s',
    en: '6 files renamed in 0.3s'
  };

  function applyLang(lang) {
    root.setAttribute('lang', lang);
    langButtons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.setLang === lang);
    });
    if (binTimeEl && binTimeEl.dataset.done === 'true') {
      binTimeEl.textContent = binTimeText[lang];
    }
    try { localStorage.setItem('zm_lang', lang); } catch (e) {}
  }

  langButtons.forEach(btn => {
    btn.addEventListener('click', () => applyLang(btn.dataset.setLang));
  });

  let initialLang = 'vi';
  try {
    initialLang = localStorage.getItem('zm_lang') || (navigator.language.startsWith('vi') ? 'vi' : 'vi');
  } catch (e) {}
  applyLang(initialLang);

  /* ---------------- Mobile menu ---------------- */
  const burger = document.getElementById('nav-burger');
  const mobileMenu = document.getElementById('mobile-menu');
  if (burger && mobileMenu) {
    burger.addEventListener('click', () => {
      const open = mobileMenu.classList.toggle('open');
      burger.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        mobileMenu.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------------- Hero bin — single orchestrated load animation ---------------- */
  function playBinDemo() {
    const rows = document.querySelectorAll('.bin-row');
    const arrow = document.getElementById('bin-arrow');
    if (prefersReducedMotion) {
      rows.forEach(r => r.classList.add('show'));
      if (arrow) arrow.classList.add('show');
      if (binTimeEl) { binTimeEl.textContent = binTimeText[root.getAttribute('lang')]; binTimeEl.dataset.done = 'true'; }
      return;
    }
    rows.forEach((row, i) => {
      const col = row.closest('.bin-pane').classList.contains('after') ? 1 : 0;
      const idx = parseInt(row.dataset.row, 10) || 0;
      const delay = col === 0 ? idx * 120 : 700 + idx * 130;
      setTimeout(() => row.classList.add('show'), delay);
    });
    setTimeout(() => arrow && arrow.classList.add('show'), 550);
    setTimeout(() => {
      if (binTimeEl) {
        binTimeEl.textContent = binTimeText[root.getAttribute('lang')];
        binTimeEl.dataset.done = 'true';
      }
    }, 1550);
  }
  window.addEventListener('DOMContentLoaded', () => setTimeout(playBinDemo, 300));

  /* ---------------- Scroll reveal ---------------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !prefersReducedMotion) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  /* ---------------- Timer strip (plays once, when scrolled into view) ---------------- */
  const timerStrip = document.getElementById('timer-strip');
  if (timerStrip && 'IntersectionObserver' in window) {
    const tio = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          timerStrip.classList.add('play');
          tio.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    tio.observe(timerStrip);
  } else if (timerStrip) {
    timerStrip.classList.add('play');
  }

  /* ---------------- Download click tracking (local stat, see db.js) ---------------- */
  document.querySelectorAll('#nav-download, #hero-download, a[href$=".exe"]').forEach(a => {
    a.addEventListener('click', () => {
      if (window.ZMDB) window.ZMDB.bumpStat('downloads').catch(() => {});
    });
  });

  /* ---------------- Contact form ---------------- */
  const form = document.getElementById('contact-form');
  const statusEl = document.getElementById('form-status');
  const statusText = {
    vi: {
      saved: 'Đã lưu tin nhắn trên trình duyệt này. Bấm nút bên dưới để gửi qua email — trang này chưa có máy chủ nên cần bước gửi thủ công.',
      openMail: 'Mở ứng dụng email',
      err: 'Vui lòng điền đầy đủ Tên, Email và Nội dung.'
    },
    en: {
      saved: 'Message saved on this browser. Click below to send it by email — this page has no backend yet, so sending still needs one manual step.',
      openMail: 'Open email app',
      err: 'Please fill in Name, Email, and Message.'
    }
  };

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const lang = root.getAttribute('lang') === 'en' ? 'en' : 'vi';
      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const message = form.message.value.trim();

      if (!name || !email || !message) {
        statusEl.textContent = statusText[lang].err;
        statusEl.className = 'form-status err';
        return;
      }

      try {
        if (window.ZMDB) await window.ZMDB.saveMessage({ name, email, message });
      } catch (err) { /* local save is best-effort */ }

      const subject = encodeURIComponent('Liên hệ từ website ZeroManual — ' + name);
      const body = encodeURIComponent(message + '\n\n— ' + name + ' (' + email + ')');
      const mailto = `mailto:thanhtuhaibabon@gmail.com?subject=${subject}&body=${body}`;

      statusEl.innerHTML = '';
      statusEl.className = 'form-status ok';
      const msg = document.createElement('span');
      msg.textContent = statusText[lang].saved + ' ';
      const link = document.createElement('a');
      link.href = mailto;
      link.textContent = statusText[lang].openMail;
      link.style.color = 'var(--teal)';
      link.style.textDecoration = 'underline';
      statusEl.appendChild(msg);
      statusEl.appendChild(link);
      form.reset();
    });
  }

  /* ---------------- Footer year ---------------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
